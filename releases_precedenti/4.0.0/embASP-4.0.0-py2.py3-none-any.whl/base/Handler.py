from abc import ABCMeta

class Handler(object):
    """A collection of InputProgram and OptionDescriptor.
    The subclasses have to implement startAsync(Callback, List, List) and startSync(List, List) methods.
    Each instance inside _programs and _options are represented by an integer (id) , respectively.
    """
    __metaclass__ = ABCMeta
    
    def __init__(self):
        self._programs = dict()  # Is where InputProgram elements are stored.
        self._options = dict()  # Is where OptionDescriptor elements are stored
        
    def addOption(self, o):
        """Add a new element inside _options dict.
        The o parameter is the new OptionDescriptor instance.
        The method return the id associate to the new added OptionDescriptor instance.
        """
        last_index = len(self._options)
        current_value = last_index
        self._options[last_index]=o
        return current_value
    
    def addProgram(self, program):
        """Add a new element inside _programs dict.
        The program param is the InputProgram instance added to the collection.
        The method return the id associate to the new added InputProgram instance.
        """
        last_index = len(self._programs)
        current_value = last_index
        self._programs[last_index]=program
        return current_value
    
    def _collect_options(self, option_index):
        """Return a list of options in _options dict, according to set of indexes given.
        If option_index is empty, the method return a list of all options.
        """
        input_option = list()
        if (not option_index):
            for k in self._options.keys():
                input_option.append(self._options.get(k))
        else:
            for index in option_index:
                input_option.append(self._options.get(index))
        return input_option
    
    def _collect_programs(self, program_index):
        """Return a list of programs in _programs dict, according to set of indexes given.
        If program_index is empty, the method return a list of all program.
        """
        input_programs = list()
        if (not program_index):
            for k in self._programs.keys():
                input_programs.append(self._programs.get(k))
        else:
            for index in program_index:
                input_programs.append(self._programs.get(index))
        return input_programs
    
    def getInputProgram(self, key):
        """Returns the specified InputProgram element
        The parameter key represents the id
        The method return the InputProgram element associate with the given key
        """
        return self._programs.get(key)
    
    def getOptionDescriptor(self, key):
        """Returns the specified OptionDescriptor element
        The parameter key represents the id
        The method return the OptionDescriptor element associate with the given key
        """
        return self._options.get(key)
    
    def removeAll(self):
        """Removes all of the elements from _programs and _options.
        Both of the collections will be empty after this method returns.
        """
        self._options.clear()
        self._programs.clear()
        
    def removeOptionFromId(self, option_id):
        """Removes the element associate within the given id from _options dict.
        option_id represents the id associate within an element.
        """
        self._options.pop(option_id)
        
    def removeOptionFromValue(self, o):
        """Removes every occurrence of a specified OptionDescriptor element from _options dict.
        the parameter o represents the element to be removed
        The method return true if one or more elements are removed, false otherwise
        """
        result=False
        for k in self._options:
            if(self._options.get(k) == o):
                self._options.pop(k)
                result=True
        return result
    
    def removeProgramFromValue(self, p):
        """Removes every occurrence of a specified InputProgram element from _programs dict.
        The parameter p represents the element to be removed
        The method return true if one or more elements are removed, false otherwise
        """
        result=False
        for k in self._programs:
            if(self._programs.get(k) == p):
                self._programs.pop(k)
                result=True
        return result
    
    def removeProgramFromId(self, program_id):
        """Removes the element associate within the given id from _programs} dict.
        The parameter program_id represents the id associate within an element
        """
        self._programs.pop(program_id)
        
    
    def startAsync(self, c, program_index=None, option_index=None):
        """This method have to be implemented by subclasses to execute solver in a asynchronous way,
        if no parameters are given, the entire sets of programs and option are used
        """
        pass
    
    def startSync(self, program_index=None, option_index=None):
        """This method have to be implemented by subclasses to execute solver in a synchronous way,
        if no parameters are given, the entire sets of programs and option are used
        """
        return None
    
    
    
    