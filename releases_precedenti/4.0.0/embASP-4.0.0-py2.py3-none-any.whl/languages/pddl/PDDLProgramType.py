class PDDLProgramType(object):
    """Represent an enumeration class that contains two constant, represents types of PDDL program"""
    PROBLEM = 0
    DOMAIN = 1
